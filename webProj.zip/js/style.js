$(document).ready(function() {
    $(".ey-open").click(function() {
        $(this).hide();
        $(".pw-field").attr("type", "password");
        $(".ey-close").show();
    });
    $(".ey-close").click(function() {
        $(this).hide();
        $(".pw-field").attr("type", "text");
        $(".ey-open").show();
    });
    $(window).scroll(function() {
        var scrollHeight = $(window).scrollTop();

        // يمكنك تغيير هذه القيمة وفقًا للارتفاع الذي تحتاجه لتنفيذ الإضافة
        var scrollThreshold = 100;
        var screenWidthThreshold = 768; // تعيين عرض الشاشة الحد الذي تريد فيه تنفيذ الكود


        $(window).scroll(function() {
            var scrollHeight = $(window).scrollTop();
            var screenWidth = window.innerWidth;
            if (screenWidth < screenWidthThreshold) {
                if (scrollHeight > scrollThreshold) {

                    $(".scroll-fade").addClass("scroll-fade-out");
                    $(".main-nav").css({
                        "position": "fixed",
                        "z-index": "10",
                        "width": "100%",
                        "background": "#FFFFFF",
                        "box-shadow": "0 0 5px #000",
                    });
                    $(".search-form").css({
                        "width": "70%"
                    });
                } else {
                    $(".scroll-fade").removeClass("scroll-fade-out");
                    $(".main-nav").css({
                        "position": "relative",
                        "background": "#FFFFFF"
                    });
                    $(".search-form").css({
                        "width": "100%"
                    });
                }
            }
        });
    });

    $('#categoryCarousel').owlCarousel({
        autoWidth: false,
        stagePadding: 10,
        margin: 15,
        nav: true,
        loop: false,

        autoplayHoverPause: true,

        navText: ['<i class="fa fa-chevron-right"></i>', '<i class="fa fa-chevron-left"></i>'],
        rtl: true, // تعيينها على true هنا لجعل العناصر تنزلق من الجهة اليمنى

        responsive: {
            0: {
                items: 2,
            },
            768: {
                items: 2,
            },
            992: {
                items: 4,
            },
            1310: {
                items: 4,
                margin: 30,
            }
        }
    });
    $('#xCarousel').owlCarousel({
        autoWidth: false,
        stagePadding: 0,
        margin: 15,
        nav: true,
        navText: ['<i class="fa fa-chevron-right"></i>', '<i class="fa fa-chevron-left"></i>'],
        rtl: true, // تعيينها على true هنا لجعل العناصر تنزلق من الجهة اليمنى

        responsive: {
            0: {
                items: 6,
            },
            768: {
                items: 6,
            },
            992: {
                items: 8,
            },
            1310: {
                items: 8,
                margin: 30,
            }
        }
    });

    $('#xCarousel2').owlCarousel({
        autoWidth: false,
        stagePadding: 10,
        margin: 15,
        nav: true,
        loop: false,

        autoplayHoverPause: true,

        navText: ['<i class="fa fa-chevron-right"></i>', '<i class="fa fa-chevron-left"></i>'],
        rtl: true, // تعيينها على true هنا لجعل العناصر تنزلق من الجهة اليمنى

        responsive: {
            0: {
                items: 2,
            },
            768: {
                items: 2,
            },
            992: {
                items: 4,
            },
            1310: {
                items: 4,
                margin: 30,
            }
        }
    });

    $('#xCarousel3').owlCarousel({
        autoWidth: false,
        stagePadding: 10,
        margin: 15,
        nav: true,
        loop: false,

        autoplayHoverPause: true,

        navText: ['<i class="fa fa-chevron-right"></i>', '<i class="fa fa-chevron-left"></i>'],
        rtl: true, // تعيينها على true هنا لجعل العناصر تنزلق من الجهة اليمنى

        responsive: {
            0: {
                items: 2,
            },
            768: {
                items: 2,
            },
            992: {
                items: 4,
            },
            1310: {
                items: 4,
                margin: 30,
            }
        }
    });
    $(".navbar-toggler").click(function() {
        $(".popup").toggleClass('showing');
        $(".overlay").fadeToggle();
    });
    $(".overlay").click(function() {
        $(this).fadeOut();
        $(".popup").removeClass('showing');

    });
    $('.navbarDropdown2').click(function() {
        $(this).next(".dropdown-menu").slideToggle();
    });


    const $stickyElementfilter = $('.sticky-element-filters');

    // تحديد اللون الذي تريد تعيينه عند التمرير
    const backgroundColorOnScrollfilter = '#fff';

    // تحديد اللون الذي تريد استعادته عند العودة إلى الأعلى
    const originalBackgroundColorfilter = '#fff';

    // تثبيت العنصر عند التمرير
    $(window).scroll(function() {
        // احصل على مكان العنصر العلوي
        const stickyElementTop = $stickyElementfilter.offset().top;

        if ($(window).scrollTop() >= stickyElementTop) {
            // إذا تم تمرير العنصر ووصل إلى الأعلى
            // غيّر خلفية العنصر إلى اللون المحدد
            $stickyElementfilter.css('background-color', backgroundColorOnScrollfilter);
        } else {
            // إذا عاد العنصر إلى وضعه الأصلي
            // استعد الخلفية إلى اللون الأصلي
            $stickyElementfilter.css('background-color', originalBackgroundColorfilter);
        }
    });



    const $stickyElement = $('.sticky-element');

    // تحديد الـ margin-top الذي تريده عند التمرير
    const marginTopOnScroll = '15px';

    // تحديد الـ margin-top الذي تريده عند العودة إلى الأعلى
    const originalMarginTop = '0px';

    // تثبيت العنصر عند التمرير
    $(window).scroll(function() {
        // احصل على مكان العنصر العلوي
        const stickyElementTop = $stickyElement.offset().top;

        if ($(window).scrollTop() >= stickyElementTop) {
            // إذا تم تمرير العنصر ووصل إلى الأعلى
            // غيّر الـ margin-top للعنصر إلى القيمة المحددة
            $stickyElement.css('padding-top', marginTopOnScroll);
        } else {
            // إذا عاد العنصر إلى وضعه الأصلي
            // استعد الـ margin-top للقيمة الأصلية
            $stickyElement.css('padding-top', originalMarginTop);
        }
    });

    // قم بتحديد الوظيفة التي سيتم تنفيذها عند النقر على الزر
    function handleButtonClick() {
        // إزالة الخلفية المفعلة من جميع الأزرار
        $('.button-status').removeClass('active-button');

        // تفعيل الخلفية للزر الذي تم النقر عليه
        $(this).addClass('active-button');
    }

    // قم بإضافة مُستمع للنقر إلى كل زر باستخدام jQuery
    $('.button-status').click(handleButtonClick);

    $(".type-desc").hide();
    $(".type-desc-title").hide();
    $(".type-desc-arrow").hide();
    $(".type-search").hide();
    $(".type").click(function() {
        $(this).hide();
        $(".status").hide();
        $(".price").hide();
        $(".type-title").hide();
        $(".type-desc-arrow").fadeIn();
        $(".type-desc-title").fadeIn();
        $(".type-desc").fadeIn();
        $(".type-search").fadeIn();

    });
    $(".back-to-filters").click(function() {
        $(this).hide();
        $(".type").show();
        $(".status").show();
        $(".price").show();
        $(".type-title").show();
        $(".type-desc-arrow").hide();
        $(".type-desc-title").hide();
        $(".type-desc").hide();
        $(".type-search").hide();

    });


    const $dropdownButtons = $(".dropdown-button");
    const $dropdownLists = $(".dropdown-list");

    $dropdownButtons.click(function() {
        const dropdownId = $(this).data("dropdown-id");
        const $dropdownList = $("#" + dropdownId);
        $dropdownList.toggle();
    });

    $(".listdown-button").on("click", function() {
        if ($(window).width() <= 768) { // تحقق من حجم الشاشة (الهواتف المحمولة)
            var dropdown = $("#" + $(this).data("dropdown-mob-status-id"));
            dropdown.toggleClass("mob-list-down-show");
            $(".overlay2").show();
        }
    });
    $(".overlay2").click(function() {
        $(this).hide();
        $(".mob-list-down").removeClass("mob-list-down-show");
    });

    $('#productCarousel').on('slid.bs.carousel', function() {
        var currentIndex = $('#productCarousel .carousel-inner .carousel-item.active').index() + 1;
        $('#currentSlide').text(currentIndex);
    });

    var totalSlides = $('#productCarousel .carousel-inner .carousel-item').length;
    $('#totalSlides').text(totalSlides);

});